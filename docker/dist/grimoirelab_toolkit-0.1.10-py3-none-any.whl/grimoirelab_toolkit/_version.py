# Versions compliant with PEP 440 https://www.python.org/dev/peps/pep-0440
__version__ = "0.1.10"
